import 'package:flutter/material.dart';
import '../widgets/animated_banner_implicit.dart';
import '../widgets/animated_banner_explicit.dart';
import '../widgets/responsive_product_grid.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white, // 🟡 warna putih fix
        elevation: 4, // optional: hilangkan bayangan agar flat
        title: Image.asset('assets/images/logo.png', height: 40),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 8),
            // Banner Promo Implisit
            const AnimatedBannerImplicit(),

            const SizedBox(height: 12),
            // Banner Promo Eksplisit
            const AnimatedBannerExplicit(),

            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    'Koleksi Terbaru',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Icon(Icons.filter_list),
                ],
              ),
            ),
            const SizedBox(height: 8),
            // Grid Produk Responsif
            const ResponsiveProductGrid(),
          ],
        ),
      ),
    );
  }
}
