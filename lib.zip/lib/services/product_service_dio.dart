import 'package:dio/dio.dart';
import '../models/product_model.dart';

class ProductServiceDio {
  final Dio _dio = Dio(BaseOptions(baseUrl: 'https://dummyjson.com'));

  Future<List<Product>> fetchProducts() async {
    try {
      final stopwatch = Stopwatch()..start();
      final response = await _dio.get('/products');
      stopwatch.stop();
      print('DIO Load Time: ${stopwatch.elapsedMilliseconds} ms');

      final List products = response.data['products'];
      return products.map((json) => Product.fromJson(json)).toList();
    } on DioException catch (e) {
      print('DIO Error: ${e.message}');
      return [];
    }
  }
}
