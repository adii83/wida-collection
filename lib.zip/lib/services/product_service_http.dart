import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/product_model.dart';

class ProductServiceHttp {
  final String baseUrl = 'https://dummyjson.com/products';

  Future<List<Product>> fetchProducts() async {
    try {
      final stopwatch = Stopwatch()..start();
      final response = await http.get(Uri.parse(baseUrl));

      if (response.statusCode == 200) {
        stopwatch.stop();
        print('HTTP Load Time: ${stopwatch.elapsedMilliseconds} ms');
        final data = jsonDecode(response.body)['products'] as List;
        return data.map((json) => Product.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load products: ${response.statusCode}');
      }
    } catch (e) {
      print('HTTP Error: $e');
      return [];
    }
  }
}
